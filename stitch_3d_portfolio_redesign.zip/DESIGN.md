---
name: Celestial Architect
colors:
  surface: '#11131d'
  surface-dim: '#11131d'
  surface-bright: '#373944'
  surface-container-lowest: '#0b0e18'
  surface-container-low: '#191b26'
  surface-container: '#1d1f2a'
  surface-container-high: '#272935'
  surface-container-highest: '#323440'
  on-surface: '#e1e1f1'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e1e1f1'
  inverse-on-surface: '#2e303b'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#d3bbff'
  on-tertiary: '#3f008d'
  tertiary-container: '#a476ff'
  on-tertiary-container: '#37007d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#ebddff'
  tertiary-fixed-dim: '#d3bbff'
  on-tertiary-fixed: '#250059'
  on-tertiary-fixed-variant: '#5b00c5'
  background: '#11131d'
  on-background: '#e1e1f1'
  surface-variant: '#323440'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md-mobile:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-mono-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system embodies the dual nature of elite technical leadership: astronomical scale and architectural precision. Designed for a high-caliber CTO and Full-Stack Architect, the aesthetic bridges deep space cosmic engineering with ethereal atmospheric daylight.

### Personality & Emotional Response
- **Authority & Executive Scale:** Evokes the certainty of planetary engineering, bulletproof security, and high-concurrency systems.
- **Atmospheric Dualism:** 
  - *Celestial Dark:* Deep space obsidian with infinite particle dust, cold starlight highlights, and gravitational purple energy pulses.
  - *Ethereal Light:* High-altitude troposphere, luminous cloud white surfaces, refracted cyan sunlight, and sharp ultraviolet focal points.
- **Hyper-Technical Elegance:** Combines clean mathematical layouts with subtle, high-performance interactions—luminescent borders, specular glass reflections, and tactile 3D control feedback.

### Visual Style
A hybrid of **Tactile Glassmorphism** and **Technical Futurism**. Translucent panels reveal subtle background ambient depths (stellar dust or diffused cloud layers). Component edges feature micron-thin gradient strokes that shimmer on hover, paired with monospaced telemetry data to ground visionary concepts in concrete engineering reality.

## Colors

The color palette reflects dual atmospheres: the deep nocturnal void of high-availability cloud architecture and the crystal-clear daytime stratosphere.

### Dark Mode (Celestial Deep Space)
- **Base Canvas (`#070913`):** Deep midnight obsidian, the infinite vacuum of space.
- **Surface Elevation 1 (`#0f1424`):** Ultra-deep navy-slate with 65% opacity for standard cards.
- **Surface Elevation 2 (`#171e38`):** Elevated glass layer with 80% opacity for modals and interactive inputs.
- **Primary Accent (`#8b5cf6`):** Electric violet—indicates active states, primary CTAs, and hero typographic gradients.
- **Secondary Accent (`#38bdf8`):** Stellar cyan—denotes system metrics, status badges, and tech stack taxonomy.
- **Deep Glow Accent (`#6d28d9`):** Cosmic purple—used for backplate ambient drop blurs, mesh gradients, and focused focus-rings.
- **Text Hierarchy:**
  - Headings & Primary Text: `#f8fafc` (98% contrast cold white).
  - Body Text: `#94a3b8` (Slate 400).
  - Subtle / Code Meta: `#64748b` (Slate 500).

### Light Mode (Ethereal Stratosphere)
- **Base Canvas:** Linear gradient from `#f0f9ff` (Sky 50) to `#e0f2fe` (Sky 100).
- **Surface Elevation 1 (`rgba(255, 255, 255, 0.75)`):** Pure cloud white frosted glass with multi-layered blur.
- **Surface Elevation 2 (`#ffffff`):** Opaque elevated card surface with soft sky-tinted drop shadows.
- **Primary Accent (`#7c3aed`):** Sunlit violet for focal CTAs and brand identity.
- **Secondary Accent (`#2563eb`):** Crisp azure blue for interactive text, links, and system indicators.
- **Text Hierarchy:**
  - Headings & Primary Text: `#0f172a` (Deep Slate 900).
  - Body Text: `#334155` (Slate 700).
  - Subtle / Code Meta: `#64748b` (Slate 500).

### Gradients & Cosmic Accents
- **Cosmic Nebula Gradient:** `linear-gradient(135deg, #8b5cf6 0%, #38bdf8 100%)`
- **Atmospheric Glow Line:** `linear-gradient(90deg, rgba(139,92,246,0) 0%, rgba(56,189,248,0.8) 50%, rgba(139,92,246,0) 100%)`

## Typography

The typography system unites futuristic structural headings, high-density humanized prose, and surgical developer tooling monospaces.

- **Headlines (Space Grotesk):** Engineered geometry with high character; carries subtle retro-futuristic nuances without sacrificing legibility. Display levels employ tight negative tracking (`-0.03em`) to deliver impact.
- **Body Copy (Inter):** Highly legible, neutral workhorse engineered for maximum legibility across variable background luminance and blurred overlays.
- **Data & Telemetry (JetBrains Mono):** Reserved for technical stack pills, system architecture callouts, metrics, time stamps, and terminal code snippets.

### Typographic Polish
- Key headlines feature dynamic two-tone or gradient emphasis: the personal name or core focus is accented via a linear gradient shifting from Primary Violet to Stellar Cyan.
- Architectural roles and metrics must be wrapped in `label-mono-md` using all-caps tracking (`letterSpacing: "0.08em"`).

## Layout & Spacing

The layout is built upon a balanced, mathematical 12-column grid system paired with strict 8pt spatial increments.

### Grid & Responsiveness
- **Desktop (>= 1200px):** 12 columns, max content container width `1240px`, centered with `2rem` outer page margins and `1.5rem` gutters.
- **Tablet (768px - 1199px):** 8 columns, `1.5rem` margins, `1rem` gutters. Multi-column cards compress to 2-column or stacked layouts.
- **Mobile (< 768px):** 4 columns, `1rem` margin, `0.75rem` gutter. Grids collapse into vertical single-column stacks with consistent `space-md` gaps.

### Section Density & Spacing Rhythm
- **Major Section Division:** `space-xl` scaled dynamically (up to `5rem` or `6rem` on desktop) creates astronomical breathing room, allowing celestial backdrops and particle constellations to establish depth.
- **Component Padding:** Internal card padding scales strictly between `space-md` (`1rem`) on compact elements and `space-lg` (`1.75rem`) on featured showcase panels.

## Elevation & Depth

Visual hierarchy leverages multi-planar glass surfaces, specular hairline borders, and atmospheric photon backlighting.

### Depth Planes
- **Ground 0 (Canvas):** Deep dark obsidian space (`#070913`) or atmospheric daylight sky (`#f0f9ff`). Host to interactive particle canvases (subtle stars or drifting cloud mist).
- **Layer 1 (Card Bases):** Glassmorphic panels with `backdrop-filter: blur(16px)` and `background: rgba(15, 20, 36, 0.65)`. Rimmed with an inner hairline highlight: `box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.08)`.
- **Layer 2 (Elevated & Active Items):** Hover states, active dropdowns, and modals shift to `background: rgba(23, 30, 56, 0.85)` with a multi-tiered elevation shadow:
  - Ambient Shadow: `0 20px 40px -15px rgba(0, 0, 0, 0.5)`.
  - Nebula Glow: `0 0 30px -5px rgba(109, 40, 217, 0.25)`.
- **Layer 3 (Floating Controls & Badges):** Solid or frosted pills (`backdrop-filter: blur(24px)`) bordered by semi-transparent primary accents (`rgba(139, 92, 246, 0.4)`).

### Atmospheric Light Mode Translation
In daylight mode, dark space shadows transition into deep atmospheric occlusion:
- Surface: `rgba(255, 255, 255, 0.85)` with `backdrop-filter: blur(20px)`.
- Borders: `1px solid rgba(226, 232, 240, 0.8)`.
- Ambient Shadow: `0 12px 32px -8px rgba(37, 99, 235, 0.08), 0 4px 12px -2px rgba(15, 23, 42, 0.04)`.

## Shapes

The design system adopts a balanced, contemporary rounded corner language (`roundedness: 2` / Base `0.5rem` to `1rem`).

- **Base Components (Inputs, Small Badges):** `0.5rem` (8px). Delivers sharp, mechanical precision.
- **Containers & Project Cards:** `1rem` (16px). Harmonizes structural stability with soft glassmorphic borders.
- **Showcase Panels & Modal Overlays:** `1.5rem` (24px). Creates distinct, modern framing for hero assets.
- **Interactive Micro-Pills (Filters, Tech Tags, CTAs):** Fully rounded pill geometry (`9999px`) provides a tactile, smooth contrast against geometric structural cards.

## Components

### Buttons
- **Primary Hero Button:** Pill-shaped (`rounded-full`), solid or radiant gradient background (`#8b5cf6` to `#6d28d9`). Features an ambient bottom bloom (`box-shadow: 0 8px 24px -4px rgba(139, 92, 246, 0.5)`). High-contrast white text (`Inter 500`). Hover adds a micro-translate (`transform: translateY(-2px)`) and intensifies bloom.
- **Secondary Ghost Button:** Translucent glass surface (`rgba(255, 255, 255, 0.05)` in dark mode, `rgba(255, 255, 255, 0.8)` in light mode) with a subtle hairline border (`1px solid rgba(255, 255, 255, 0.15)`). On hover, border color shifts to stellar cyan (`#38bdf8`) with a subtle matching glow.

### Filter & Category Chips
- **Geometry:** Pill-shaped, compact (`padding: 0.35rem 1rem`), JetBrains Mono (`label-mono-md`).
- **Inactive:** Transparent background, `border: 1px solid rgba(255, 255, 255, 0.1)`, muted slate text (`#94a3b8`).
- **Active / Selected:** Radiant violet fill (`#8b5cf6` in dark mode, `#7c3aed` in light mode), pure white text, accompanied by an electric glow shadow.

### Cards (Featured Projects & Skill Clusters)
- **Base Grid Cards (Skills & Supporting Projects):** Surface Layer 1 glass cards, bordered by a soft `1px` border of `rgba(255, 255, 255, 0.08)`. On cursor hover, the border dynamically highlights along the gradient of the primary and secondary colors, and the card tilts up slightly (3D perspective transform).
- **Featured Project Hero Card:** 12-column flagship container. Split 50/50 between a high-fidelity visual preview frame on the left and comprehensive technical breakdown on the right (System Architecture, Stack Badges, Live Action Buttons). Inner background utilizes an intensified dark glass tint (`rgba(10, 14, 28, 0.8)`).

### Input Fields & Contact Terminal
- **Form Controls:** Frosted dark-fill text inputs (`rgba(7, 9, 19, 0.6)`) encased in subtle slate borders (`rgba(148, 163, 184, 0.2)`).
- **Focus State:** Border switches instantaneously to stellar cyan (`#38bdf8`) with a soft outer ring (`0 0 0 3px rgba(56, 189, 248, 0.2)`). Text remains crisp white with placeholder in muted slate (`#64748b`).

### Badges & Technology Tags
- **Micro Tech Chips:** Compact pills with dark semi-transparent fill (`rgba(139, 92, 246, 0.15)`), bordered with `rgba(139, 92, 246, 0.3)`. Text is set in `JetBrains Mono` (`label-mono-sm`) with a vibrant primary violet hue.